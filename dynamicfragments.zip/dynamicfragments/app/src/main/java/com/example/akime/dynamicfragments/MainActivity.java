package com.example.akime.dynamicfragments;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.CompoundButton;
import android.widget.Switch;

import static android.support.v7.appcompat.R.styleable.CompoundButton;
import static com.example.akime.dynamicfragments.R.id.mySwitch;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Switch mySwitch = (Switch) findViewById(R.id.mySwitch);

        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // do something, the isChecked will be
                // true if the switch is in the On position

                FragmentManager fm1 = getFragmentManager();
                FragmentTransaction fragmentTransaction1 = fm1.beginTransaction();
                if (isChecked) {
                    Fragment1 f1 = new Fragment1();
                    fragmentTransaction1.replace(R.id.fragment_placeholder, f1);
                } else {
                    Fragment2 f2 = new Fragment2();
                    fragmentTransaction1.replace(R.id.fragment_placeholder, f2);
                }
                fragmentTransaction1.commit();
            }
        });


        FragmentManager fm = getFragmentManager();
        FragmentTransaction fragmentTransaction = fm.beginTransaction();

        if (mySwitch.isChecked()) {
            Fragment1 f1 = new Fragment1();
            fragmentTransaction.replace(R.id.fragment_placeholder, f1);
        } else {
            Fragment2 f2 = new Fragment2();
            fragmentTransaction.replace(R.id.fragment_placeholder, f2);
        }
        fragmentTransaction.commit();
    }


}
